### Will update this to Discord.js 13 soon and will add more cmds

![MOSHED-2021-4-27-14-48-27](https://user-images.githubusercontent.com/79590499/116218250-f8a58800-a767-11eb-86fa-9c1ea5797100.jpg)

[![Run on Repl.it](https://replit.com/badge/github/Monochromish/Kalopsia-Bot)](https://repl.it/github/Monchromish/Kalopsia-Bot)
# Kalopsia-Bot ♣️
Kalopia Bot is an Open-Source Discord Bot written in JavaScript
Please Star this Project if you like the bot

## Commands 🤖
**Admin and Moderator Commands** such as Ban, Kick, Mute, Lockchannel, Slowmode, Say, etc..
**Economy Commands** such as Balance, Deposit, Rob, etc...,
**Fun Commands** such as 8ball, Kiss, DM, etc...,
**Meme Commands** such as Triggered, Slap, Meme, etc...,
**Music Commands** such as Play, Filter, Seek, etc...,
**Nsfw Commands** such as Anal, Boobs, 4k, etc...,
**Utility Commands** such as Avatar, Calculator, Weather, etc...,
I will be adding some more commands such as AFK Commands and Fun Commands

## Installation 📥

This bot uses **MongoDB** so if you want to self-host it, you would require a MongoURL
**REFER TO THIS VIDEO FOR HELP => https://www.youtube.com/watch?v=8no3SktqagY**

After you have your MongoURL
it should look something like this => mongodb+srv://<username>:<password>@cluster0.zzuon.mongodb.net/test,
Replace **username** with your MongoDB Username,
Replace **password** with your MongoDB Password,
And Replace /test at the end with /data
  
Now, clone the .env.example file and name it .env,
inside the .env file replace "prefix" with a word or a symbol that will be your bot prefix,
Replace "monogourl" with your MongoURL,
Replace "token" with your bot token

After thats done, we now need to install some modules and for that go in the terminal and run the command **npm i** / **npm install**
The command should install all the modules, it would take time

## Self Hosting 🚩

After you have Installed the modules and modified the configuration file (.env file), You can now run the bot by using the command **node .**
And that's it, your bot should be running

## Came across an issue? or need help with the bot? ℹ️

If you find a bug or if you are facing it difficulties in hosting the bot, Contact me on Discord... **500315184510795819** <= this is my ID

## Credit & Support ❤️

**This bot was fully made by Monochromish (500315184510795819)**
